import 'package:flutter/material.dart';

class MyEdit extends StatefulWidget {
  const MyEdit({super.key});
  @override
  State<MyEdit> createState() => _MyEditState();
}

class _MyEditState extends State<MyEdit> {
  final userController = Get.put(UserController());
  final fileController = Get.put(FileController()); // 추가
  final _nameController = TextEditingController();

  _submit() async {
    bool result = await userController.updateInfo(
      _nameController.text,
      fileController.imageId.value,
    );
    @override
    void initState() {
      super.initState();
      _nameController.text = userController.my.value!.name;
      fileController.imageId.value = userController.my.value?.profile; // 추가
    }

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('프로필 수정'),
        ),
        body: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          children: [
            InkWell(
              // 추가
              onTap: fileController.upload,
              child: Obx(
                () => CircleImage(fileController.imageUrl),
              ),
            ),
            const SizedBox(height: 16),
            LabelTextField(
              label: '닉네임',
              hintText: '닉네임을 입력해주세요',
              controller: _nameController,
            ),
            // 버튼
            ElevatedButton(
              onPressed: _submit,
              child: const Text('저장'),
            ),
          ],
        ),
      );
    }
  }
}
