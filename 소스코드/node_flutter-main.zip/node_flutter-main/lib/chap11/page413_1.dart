Future<void> main() async {
  // GetStorage 초기화
  await GetStorage.init();
  final box = GetStorage();

  // 로그인 여부 판단
  String? token = box.read('access_token');
  bool isLogin = (token != null) ? true : false;

  runApp(MyApp(isLogin));
}
