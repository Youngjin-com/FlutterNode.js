class Global {
  static const String baseUrl = 'http://localhost:3000';
  static const String chatUrl = 'ws://localhost:3000';
}
