import 'dart:developer';
import '../providers/auth_provider.dart';
import '../shared/global.dart';

class AuthController extends GetxController {
  final authProvider = Get.put(AuthProvider());
  String? phoneNumber; // requestVerificationCode 함수에서 기록한 폰번호
  Future<bool> register(String password, String name, int? profile) async {
    Map body =
        await authProvider.register(phoneNumber!, password, name, profile);
    if (body['result'] == 'ok') {
      String token = body['access_token'];
      log("token : $token"); // 'dart:developer' 패키지 내의 log 함수
      Global.accessToken = token;
      return true;
    }
    Get.snackbar('회원가입 에러', body['message'],
        snackPosition: SnackPosition.BOTTOM);
    return false;
  }

  Future<bool> login(String phone, String password) async {
    Map body = await authProvider.login(phone, password);
    if (body['result'] == 'ok') {
      String token = body['access_token'];
      log("token : $token");
      Global.accessToken = token;
      return true;
    }
    Get.snackbar('로그인 에러', body['message'],
        snackPosition: SnackPosition.BOTTOM);
    return false;
  }
}
