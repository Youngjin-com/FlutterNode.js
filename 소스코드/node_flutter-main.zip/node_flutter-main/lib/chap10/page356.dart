import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MyApp extends StatelessWidget {
  final bool isLogin;
  const MyApp(this.isLogin, {super.key});
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      initialRoute: isLogin ? '/' : '/intro',
      routes: {
        '/': (context) => const HomeScreen(),
        '/intro': (context) => const IntroScreen(),
        '/register': (context) => const RegisterScreen(),
      },
    );
  }
}
