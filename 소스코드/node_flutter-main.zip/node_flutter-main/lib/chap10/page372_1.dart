class FeedProvider extends Provider {
  Future<Map> store(
      String title, String price, String content, int? image) async {
    final Map<String, dynamic> body = {
      'title': title,
      'price': price,
      'content': content,
    };
    if (image != null) {
      body['imageID'] = image.toString();
    }
    final response = await post('/api/feed', body);
    return response.body;
  }
}
