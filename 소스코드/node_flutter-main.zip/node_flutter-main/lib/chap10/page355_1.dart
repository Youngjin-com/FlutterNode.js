class Global {
  static String accessToken = '';
  static const String baseUrl = 'http://localhost:3000';
}
