import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'src/app.dart';
import 'src/shared/global.dart';

void main() {
  String token = Global.accessToken;
  bool isLogin = token.isNotEmpty; // 토큰이 존재하면 로그인 상태로 판단
  runApp(MyApp(isLogin));
}
