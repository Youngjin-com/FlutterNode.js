class FeedProvider extends Provider {
// 피드 리스트 요청: 간소화된 방식
  Future<Map> index({int page = 1}) async {
    final response = await get('/api/feed', query: {'page': '$page'});
    return response.body;
  }
}
