class FeedProvider extends Provider {
  // 피드 리스트 (매물 목록) 요청
  Future<Map> index({int page = 1}) async {
    final response = await get(
      '/api/feed',
      query: {'page': '$page'},
      headers: {'Authorization': 'Bearer ${Global.accessToken}'},
    );
    return response.body;
  }
}
