import 'package:flutter/material.dart';

class FeedListItem extends StatelessWidget {
  const FeedListItem({super.key});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 이미지 영역
          // 정보 영역
          // 기타 영역
        ],
      ),
    );
  }
}
