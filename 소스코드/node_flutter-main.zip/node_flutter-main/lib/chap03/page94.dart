import 'package:flutter/material.dart';
import 'screens/feed/show.dart';
import 'screens/intro.dart';
import 'screens/auth/register.dart';
import 'screens/unknown.dart';
import 'shared/data.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Carrot Market',
      routes: {
        '/': (context) => const Intro(),
        '/register': (context) => const Register(),
      },
      initialRoute: '/',
      onGenerateRoute: (route) {
        // '/feed/:id' 형식의 경로를 위한 라우트 설정
        if (route.name!.startsWith('/feed/')) {
          // 경로에서 id를 추출하여 변수에 저장
          final id = int.parse(route.name!.split('/').last);
          // 추출한 id에 해당하는 항목을 찾습니다.
          final item = feedList.firstWhere((e) => e['id'] == id);
          return MaterialPageRoute(
            builder: (context) => FeedShow(item),
          );
        }
        // 다른 경로에 대한 처리
        return MaterialPageRoute(
          builder: (context) => const UnknownScreen(),
        );
      },
    );
  }
}
