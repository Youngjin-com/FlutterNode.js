import 'package:flutter/material.dart';

class FeedShow extends StatelessWidget {
  const FeedShow({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('텀블러 팔기'),
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('텀블러 팝니다'),
            Text('가격 : 500 원'),
          ],
        ),
      ),
    );
  }
}
