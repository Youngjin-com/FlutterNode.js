const List<Map<String, dynamic>> feedList = [
  {
    'id': 1,
    'title': '텀블러',
    'content': '텀블러 팝니다',
    'price': 500,
  },
  {
    'id': 2,
    'title': '머그잔',
    'content': '머그잔 텀블러 랑 교환도 합니다.',
    'price': 300,
  },
];
