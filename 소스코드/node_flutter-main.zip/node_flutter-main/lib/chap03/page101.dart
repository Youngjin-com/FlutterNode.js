import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SliverAppBar(
          expandedHeight: 220.0,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
            title: Text("피드 상세 보기"),
            background: Image.network(
              'https://example.com/image.jpg',
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }
}
