void main() {
  // 'age' 변수는 정수형 또는 null을 저장할 수 있는 옵셔널１ 타입입니다.
  int? age;
  age = null;
  // 이 변수에 null을 할당함으로써, null 처리를 안전하게 수행합니다.
  // 'weight'는 초기 선언 시 타입이 명시되지 않습니다.
  // 이후 값이 할당되면 그 타입으로 추론됩니다.
  var weight;
  // 여기서 'weight'는 정수형으로 추론됩니다.
  weight = 50;
  // 'name'은 문자열 또는 null을 저장할 수 있는 옵셔널 타입입니다.
  String? name;
  // 문자열 'Dart'를 할당하며, 이 변수가 null을 포함할 수 있음을 나타냅니다.
  name = 'Dart';
}
