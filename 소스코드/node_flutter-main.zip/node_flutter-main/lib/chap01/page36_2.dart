class Point {
  final int x;
  final int y;
  // 초기화 리스트를 사용한 생성자
  Point(int x, int y)
      : x = x,
        y = y {}
}

class ImmutablePoint {
  final int x;
  final int y;
  // 상수 생성자
  const ImmutablePoint(this.x, this.y);
}

void main() {
  // 상수 인스턴스 생성
  const point = ImmutablePoint(2, 3);
  print(point.x); // 출력: 2
}
