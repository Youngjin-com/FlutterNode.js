class Person {
  String name;
  int age;
  // 생성자
  Person(this.name, this.age);
  // 인사 메시지 출력 메서드
  void greet() {
    print("제 이름은 $name이고, $age 살입니다.");
  }
}

void main() {
  // Person 클래스의 인스턴스 생성
  var alice = Person("Alice", 30);
  var bob = Person("Bob", 25);
  // greet 메서드 호출
  alice.greet(); // 출력: 제 이름은 Alice이고 30 살입니다.
  bob.greet(); // 출력: 제 이름은 Bob이고 25 살입니다.
}
