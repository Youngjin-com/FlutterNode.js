class Car {
  String make;
  String bodyType;
  // 명명된 생성자
  Car.sports(this.make) : bodyType = 'Sports';
  void displayInfo() {
    print('차량 제조사: $make, 차량 타입: $bodyType');
  }
}

void main() {
  var sportsCar = Car.sports('Ferrari');
  sportsCar.displayInfo(); // 출력: 차량 제조사: Ferrari, 차량 타입: Sports
}
