class Engine {
  void start() {
    print("엔진이 시작됩니다.");
  }
}

class Car {
  final engine;

  Car(this.engine);
  void start() {
    engine.start(); // Car 객체의 start 메서드가 호출되면,
    // 포함된 Engine 객체의 start 메서드를 호출
    print("자동차가 움직입니다.");
  }
}

void main() {
  var engine = Engine();
  var myCar = Car(engine);
  myCar.start();
  // 출력:
  // 엔진이 시작됩니다.
  // 자동차가 움직입니다.
}
