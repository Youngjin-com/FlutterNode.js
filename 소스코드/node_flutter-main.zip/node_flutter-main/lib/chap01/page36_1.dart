class Singleton {
  static final Singleton _instance = Singleton._internal();
  // 팩토리 생성자를 통해 항상 같은 인스턴스 반환
  factory Singleton() {
    return _instance;
  }
  // 내부 생성자
  Singleton._internal();
}

void main() {
  var s1 = Singleton();
  var s2 = Singleton();
  print(identical(s1, s2)); // 출력: true
}
