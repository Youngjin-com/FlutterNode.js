class Vehicle {
  void move() {
    print('차량이 움직입니다.');
  }
}

class Car extends Vehicle {
  @override
  void move() {
    print('자동차가 달립니다.');
  }
}

void main() {
  final car = Car();
  car.move(); // 출력: 자동차가 달립니다.
}
