class Car {
  String make;
  String bodyType;
  // 클래스 생성자
  Car(this.make, this.bodyType);
  // 메서드를 통해 객체의 정보를 출력
  void displayInfo() {
    print('차량 제조사: $make');
    print('차량 타입: $bodyType');
  }
}

void main() {
  // Car 클래스의 인스턴스 생성
  var myCar = Car('Hyundai', 'Sedan');
  // 인스턴스의 메서드 호출
  myCar.displayInfo();
}
