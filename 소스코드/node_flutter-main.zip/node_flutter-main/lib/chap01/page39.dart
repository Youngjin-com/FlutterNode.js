abstract class Shape {
  void draw(); // 추상 메서드
}

class Circle implements Shape {
  @override
  void draw() {
    print('원을 그립니다.');
  }
}

void main() {
  final circle = Circle();
  circle.draw(); // 출력: 원을 그립니다.
}
