void main() {
  // 정수 리스트를 정의합니다.
  List<int> numbers = [1, 2, 3, 4, 5];
  // 각 요소를 두 배로 만듭니다.
  var doubledNumbers = numbers.map((n) => n * 2).toList();
  // 짝수만 필터링합니다.
  var evenNumbers = numbers.where((n) => n % 2 == 0).toList();
  // 모든 요소의 합을 계산합니다.
  int sum = numbers.reduce((cur, n) => cur + n);
  print(doubledNumbers); // [2, 4, 6, 8, 10]
  print(evenNumbers); // [2, 4]
  print(sum); // 15
}
