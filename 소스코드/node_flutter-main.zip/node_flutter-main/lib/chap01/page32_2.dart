void main() {
  // 람다 표현식을 사용한 예제
  var multiply = (int a, int b) => a * b;
  print(multiply(2, 3)); // 출력: 6
}
