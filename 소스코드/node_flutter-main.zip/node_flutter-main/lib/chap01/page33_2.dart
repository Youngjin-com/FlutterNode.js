void main() {
  // 명명된 옵셔널 파라미터를 사용하는 예제
  void greet(String name, {String prefix = 'Hi'}) {
    print('$prefix $name');
  }

  greet('Jess'); // 출력: Hi Jess
  greet('Jess', prefix: 'Hello'); // 출력: Hello Jess

  // 위치 기반 옵셔널 파라미터를 사용하는 예제
  void greetNew(String name, [String prefix = 'Hello']) {
    print('$prefix $name');
  }

  greetNew('Jess'); // 출력: Hello Jess
  greetNew('Jess', 'Welcome'); // 출력: Welcome Jess
}
