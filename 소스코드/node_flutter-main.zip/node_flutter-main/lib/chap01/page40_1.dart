mixin Musical {
  void playMusic() {
    print('음악을 연주합니다.');
  }
}

class Musician with Musical {}

void main() {
  final musician = Musician();
  musician.playMusic(); // 출력: 음악을 연주합니다.
}
