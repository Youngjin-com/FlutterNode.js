// 여기서 numbers는 쇼핑 목록의 가격 리스트
List processNumbers(List<int> numbers, Function(int) processor) {
  // map 메서드를 사용해서, 리스트의 각 가격에 processor 함수
  // (여기서는 두 배로 만드는 연산)를 적용
  return numbers.map(processor).toList();
}

void main() {
  // 쇼핑 목록의 가격. 각 가격을 두 배로 만들고 싶다면
  var prices = [10, 20, 30, 40];
  // processNumbers 함수에 가격 리스트와,
  // 가격을 두 배로 만드는 함수를 넘겨줍니다.
  var doubledPrices = processNumbers(prices, (price) => price * 2);
  print(doubledPrices); // 출력: [20, 40, 60, 80]
}
