// 숫자를 특정 값만큼 증가시키는 함수를 생성하는 함수
Function createIncrementer(int incrementBy) {
  // 클로저: incrementBy 값을 기억하고 이를 사용하는 함수 반환
  return (int number) => number + incrementBy;
}

void main() {
  var incrementByTwo = createIncrementer(2); // 2 증가시키는 함수 생성
  print(incrementByTwo(3)); // 출력: 5 (3 + 2)
  print(incrementByTwo(4)); // 출력: 6 (4 + 2)
}
