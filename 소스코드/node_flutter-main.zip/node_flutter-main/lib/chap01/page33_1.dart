void main() {
  // 익명 함수를 사용한 예제
  var names = ['Chris', 'Tina', 'Jess'];
  names.forEach((name) {
    print(name);
  });
}
