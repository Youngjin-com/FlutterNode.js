import 'package:flutter/material.dart';
import '../../widgets/buttons/category_button.dart';

class FeedIndex extends StatefulWidget {
  const FeedIndex({super.key});
  @override
  State<FeedIndex> createState() => _FeedIndexState();
}

class _FeedIndexState extends State<FeedIndex> {
  List<Map<String, dynamic>> feedList = [
    {
      'id': 1,
      'title': '텀블러',
      'content': '텀블러 팝니다',
      'price': 500,
    },
    {
      'id': 2,
      'title': '머그잔',
      'content': '머그잔 텀블러 랑 교환도 합니다.',
      'price': 300,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: const Text('내 동네'),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.search),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                CategoryButton(icon: Icons.menu),
                SizedBox(width: 12),
                CategoryButton(icon: Icons.search, title: '알바'),
                SizedBox(width: 12),
                CategoryButton(icon: Icons.home, title: '부동산'),
                SizedBox(width: 12),
                CategoryButton(icon: Icons.car_crash, title: '중고차'),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                FeedListItem(),
                FeedListItem(),
                FeedListItem(),
                FeedListItem(),
                FeedListItem(),
              ],
            ),
          )
        ],
      ),
    );
  }
}
