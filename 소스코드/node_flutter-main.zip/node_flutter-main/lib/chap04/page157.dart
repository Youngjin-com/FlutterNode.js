import 'package:flutter/material.dart';

class MyCounter1 extends StatefulWidget {
  const MyCounter1({super.key});
  @override
  State<MyCounter1> createState() => _MyCounterState();
}

class _MyCounterState extends State<MyCounter1> {
  int counter = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            counter++;
          });
        },
      ),
      body: Center(
        child: Text("카운터 : $counter"),
      ),
    );
  }
}
