import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MyCounter2 extends StatefulWidget {
  const MyCounter2({super.key});
  @override
  State<MyCounter2> createState() => _MyCounterState();
}

class _MyCounterState extends State<MyCounter2> {
  RxInt counter = 0.obs;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          counter.value++;
        },
      ),
      body: Center(
        child: Obx(() => Text("카운터 : $counter")),
      ),
    );
  }
}
