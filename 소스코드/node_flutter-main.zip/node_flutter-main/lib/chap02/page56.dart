import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    int _selectedIndex = 0; // 현재 선택된 위젯의 인덱스

    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: IndexedStack(
            index: _selectedIndex, // 표시할 자식 위젯의 인덱스
            children: <Widget>[
              Container(
                color: Colors.red,
                child: Center(
                  child: Text('첫 번째 페이지',
                      style: TextStyle(color: Colors.white, fontSize: 24)),
                ),
              ),
              Container(
                color: Colors.green,
                child: Center(
                  child: Text('두 번째 페이지',
                      style: TextStyle(color: Colors.white, fontSize: 24)),
                ),
              ),
              Container(
                color: Colors.blue,
                child: Center(
                  child: Text('세 번째 페이지',
                      style: TextStyle(color: Colors.white, fontSize: 24)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
