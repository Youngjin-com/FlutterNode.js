import 'package:flutter/material.dart';

void main() {
  TextFormField(
    decoration: InputDecoration(labelText: '이메일'),
    validator: (value) {
      if (value == null || value.isEmpty) {
        return '이메일을 입력해주세요';
      }
      return null; // 유효성 검사 통과
    },
  );
}
