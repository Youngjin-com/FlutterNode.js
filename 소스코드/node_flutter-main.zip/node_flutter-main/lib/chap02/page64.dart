import 'package:flutter/material.dart';

void main() {
  Column(
    children: [
      // 일반적으로 사용되는 입체감이 있는 버튼입니다
      ElevatedButton(
        onPressed: () {
          // 버튼이 눌렸을 때 실행될 코드
        },
        child: Text('Elevated Button'),
      ),
      // 텍스트로만 구성된 버튼입니다.
      TextButton(
        onPressed: () {
          // 버튼이 눌렸을 때 실행될 코드
        },
        child: Text('Text Button'),
      ),
      // 테두리가 있는 버튼입니다.
      OutlinedButton(
        onPressed: () {
          // 버튼이 눌렸을 때 실행될 코드
        },
        child: Text('Outlined Button'),
      ),
    ],
  );
}
