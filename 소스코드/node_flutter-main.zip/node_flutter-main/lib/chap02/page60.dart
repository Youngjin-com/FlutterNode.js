import 'package:flutter/material.dart';

void main() {
  // 로컬 이미지 로드
  Image(image: AssetImage('assets/images/example.png'));
  // 네트워크 이미지 로드
  Image(image: NetworkImage('https://example.com/image.jpg'));
  // 로컬 이미지 다른 방식
  Image.asset('assets/images/example.png');
  // 네트워크 이미지 다른 방식
  Image.network('https://example.com/image.jpg');
}
