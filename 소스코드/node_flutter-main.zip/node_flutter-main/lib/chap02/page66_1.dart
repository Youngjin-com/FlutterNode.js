import 'package:flutter/material.dart';

void main() {
  TextField(
    decoration: InputDecoration(
      labelText: '이름',
      hintText: '여기에 이름을 입력하세요',
      border: OutlineInputBorder(),
      icon: Icon(Icons.person),
    ),
    onChanged: (text) {
      // 사용자 입력이 변경될 때마다 호출되는 함수
      print("현재 입력값: $text");
    },
    onSubmitted: (text) {
      // 사용자가 입력을 완료하고 제출할 때 호출되는 함수
      print("최종 입력값: $text");
    },
    controller: TextEditingController(),
    keyboardType: TextInputType.name,
    textInputAction: TextInputAction.done,
  );
}
