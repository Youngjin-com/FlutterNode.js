import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: Center(
            child: Stack(
              children: <Widget>[
                Container(width: 300, height: 300, color: Colors.blue),
                Positioned(
                  top: 0,
                  left: 0,
                  child:
                      Container(width: 100, height: 100, color: Colors.green),
                ),
                Positioned(
                  bottom: 0,
                  left: 0,
                  child: Container(width: 100, height: 100, color: Colors.red),
                ),
                Positioned(
                  top: 0,
                  right: 0,
                  child:
                      Container(width: 100, height: 100, color: Colors.yellow),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child:
                      Container(width: 100, height: 100, color: Colors.orange),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
