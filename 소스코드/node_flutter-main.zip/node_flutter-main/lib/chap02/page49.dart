import 'package:flutter/material.dart';

void main() {
  Row(
    children: [
      Text('hello'),
      Text('world'),
    ],
  );

  Column(
    children: [
      Text('hello'),
      Text('world'),
    ],
  );
}
