import 'package:flutter/material.dart';

void main() {
  // 단순한 색상 변경
  Text("표시할 내용", style: TextStyle(color: Colors.red));
  // 색상과 폰트 크기 조정
  Text("표시할 내용", style: TextStyle(color: Colors.red, fontSize: 16.0));
  // 텍스트의 두께 변경
  Text("표시할 내용", style: TextStyle(fontWeight: FontWeight.bold));
}
