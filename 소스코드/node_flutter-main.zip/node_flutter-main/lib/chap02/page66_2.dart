import 'package:flutter/material.dart';

void main() {
  final controller = TextEditingController();

  TextField(
    controller: controller,
    decoration: InputDecoration(
      labelText: '이름',
      hintText: '여기에 이름을 입력하세요',
      border: OutlineInputBorder(),
    ),
  );
  // 컨트롤러를 통해 현재 텍스트 필드의 텍스트를 얻을 수 있습니다.
  String text = controller.text;
  print(text);
  // 컨트롤러를 사용하여 텍스트 필드의 텍스트를 프로그래밍 방식으로 변경할 수 있습니다.
  controller.text = "초기화 할 문구";
}
