import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('StatelessWidget 변화 과정'),
        ),
        body: Center(
          child: MyContainer(),
        ),
      ),
    );
  }
}

class MyContainer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // MyContainer 클래스 내에서 Container 위젯을 반환합니다.
    return Container(
      width: 100,
      height: 100,
      color: Colors.blue,
    );
  }
}
