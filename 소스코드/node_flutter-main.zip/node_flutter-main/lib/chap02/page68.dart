import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    final _formKey = GlobalKey<FormState>();

    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                TextFormField(
                  decoration: InputDecoration(labelText: '이메일'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return '이메일 주소를 입력하세요';
                    }
                    if (!value.contains('@')) {
                      return '유효한 이메일 주소를 입력하세요';
                    }
                    return null;
                  },
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: ElevatedButton(
                    onPressed: () {
                      // 폼이 유효한지 검사합니다.
                      if (_formKey.currentState!.validate()) {
                        // 폼이 유효한 경우, 실제 처리를 수행합니다.
                        // 예: 서버에 폼 데이터 제출
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(content: Text('처리 중')));
                      }
                    },
                    child: Text('제출'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
