import 'package:flutter/material.dart';

void main() {
  // 일반적인 Text Widget의 사용
  Text("표시할 내용");
  Text('표시할 내용');
  // 여러 줄의 Text
  Text('''여러 줄
인 경우''');
  // 문자열 내의 변수를 포함할 경우
  int count = 5;
  List<int> myList = [1, 2, 3];
  Text("표시할 내용 ${myList[1]}");
  Text('표시할 내용 $count');
}
