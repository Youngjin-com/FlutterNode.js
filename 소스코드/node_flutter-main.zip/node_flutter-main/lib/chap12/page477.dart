import 'package:flutter/material.dart';
import 'package:get/get.dart';

// 이미지 크기
const double _imageSize = 110;

class FeedListItem extends StatelessWidget {
  final FeedModel data;
  const FeedListItem(this.data, {super.key}); // 생성자 추가
  @override
  Widget build(BuildContext context) {
    final FeedController feedController = Get.put(FeedController());

    return InkWell(
      onTap: () {
        Get.to(() => FeedEdit(item: data));
      },
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Stack(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 이미지 영역
                ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: Image.network(
                    "https://example.com/image.jpg",
                    width: _imageSize,
                    height: _imageSize,
                    fit: BoxFit.cover,
                  ),
                ),
                // 정보 영역
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          data.title, // data['title'],
                          style: TextStyle(fontSize: 16),
                          overflow: TextOverflow.ellipsis,
                        ),
                        Row(
                          children: [
                            Text(
                              TimeUtil.parse(data.createdAt),
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                        Text(
                          data.price.toString(), // data['price'].toString(),
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
                // 기타 영역
                IconButton(
                  onPressed: () {
                    showModalBottomSheet(
                      context: context,
                      builder: (context) {
                        return MoreBottomModal(
                          delete: data.isMe
                              ? () {
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return ConfirmModal(
                                        title: '삭제 하기',
                                        message:
                                            '이 글을 삭제하시겠습니까? 삭제한 글은 다시 볼 수 없습니다.',
                                        confirmText: '삭제하기',
                                        confirmAction: () async {
                                          bool result = await feedController
                                              .feedDelete(data.id);
                                          if (result) {
                                            Navigator.pop(context);
                                            Navigator.pop(context);
                                          }
                                        },
                                        cancel: () {
                                          Navigator.pop(context); // Dialog 닫기
                                        },
                                      );
                                    },
                                  );
                                }
                              : null,
                          cancelTap: () {
                            Navigator.pop(context);
                          },
                          hideTap: () {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return ConfirmModal(
                                  title: '글 숨기기',
                                  message: '이 글을 숨기시겠습니까? 숨긴 글은 다시 볼 수 없습니다.',
                                  confirmText: '숨기기',
                                  confirmAction: () {
                                    // 여기에 글을 숨기는 로직을 구현합니다.

                                    Navigator.pop(context); // Dialog 닫기
                                    Navigator.pop(
                                        context); // MoreBottomModal 닫기
                                  },
                                  cancel: () {
                                    Navigator.pop(context); // Dialog 닫기
                                  },
                                );
                              },
                            );
                          },
                        );
                      },
                    );
                  },
                  icon: const Icon(
                    Icons.more_vert,
                    color: Colors.grey,
                    size: 16,
                  ),
                )
              ],
            ),
            // 정보 영역
            Positioned(
              right: 10,
              bottom: 0,
              child: Row(
                children: [
                  Icon(
                    Icons.chat_bubble_outline,
                    color: Colors.grey,
                    size: 16,
                  ),
                  SizedBox(width: 2),
                  Text(
                    '1',
                    style: TextStyle(color: Colors.grey),
                  ),
                  SizedBox(width: 4),
                  Icon(
                    Icons.favorite_border,
                    color: Colors.grey,
                    size: 16,
                  ),
                  SizedBox(width: 2),
                  Text(
                    '${data.favoriteCount}',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
