import 'dart:math';
import 'package:get/get.dart';
import '../models/feed_model.dart';
import '../providers/feed_provider.dart';

class FeedController extends GetxController {
  final feedProvider = Get.put(FeedProvider());
  RxList<FeedModel> feedList = <FeedModel>[].obs;
  void addData() {
    final random = Random();
    final newItem = FeedModel.parse({
      'id': random.nextInt(100),
      'title': '제목 ${random.nextInt(100)}',
      'content': '설명 ${random.nextInt(100)}',
      'price': 500 + random.nextInt(49500),
    });
    feedList.add(newItem);
  }

  void updateData(FeedModel updatedItem) {
    final index = feedList.indexWhere((item) => item.id == updatedItem.id);
    if (index != -1) {
      feedList[index] = updatedItem;
    }
  }
}
