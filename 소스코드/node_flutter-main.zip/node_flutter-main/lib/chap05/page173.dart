// BLoC
import 'package:flutter/material.dart';

class CounterBloc {
  int _count = 0;
  final _countController = StreamController<int>();
  Stream<int> get countStream => _countController.stream;
  void increment() {
    _count++;
    _countController.sink.add(_count);
  }

  void dispose() {
    _countController.close();
  }
}

// View
class CounterView extends StatelessWidget {
  final CounterBloc bloc = CounterBloc();
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<int>(
      stream: bloc.countStream,
      builder: (context, snapshot) {
        final count = snapshot.data ?? 0;
        return ElevatedButton(
          onPressed: () => bloc.increment(),
          child: Text('Increment ($count)'),
        );
      },
    );
  }
}
