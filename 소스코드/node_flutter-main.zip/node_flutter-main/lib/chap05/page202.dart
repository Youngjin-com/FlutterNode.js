import 'dart:math';
import 'package:get/get.dart';
import '../models/feed_model.dart';
import '../providers/feed_provider.dart';

class FeedController extends GetxController {
  final feedProvider = Get.put(FeedProvider());
  RxList<Map> feedList = <Map>[].obs;
  // 이하 생략...